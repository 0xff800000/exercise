/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_2592010699;
static const char *ng1 = "C:/Users/DYB/Documents/EPFL/Syn_sim/exII2_post_syn/async_counter_tb.vhd";

unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );


void work_a_1810025488_0224828019_sub_2255900711_563975177(char *t0, char *t1, int t2)
{
    char t4[8];
    char *t5;
    int t6;
    int t7;
    int t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int64 t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t5 = (t4 + 4U);
    *((int *)t5) = t2;
    t6 = (t2 - 1);
    t7 = t6;
    t8 = 0;

LAB2:    if (t7 >= t8)
        goto LAB3;

LAB5:
LAB1:    return;
LAB3:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t11);
    t9 = (t0 + 3080);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t12;
    xsi_driver_first_trans_fast(t9);
    t9 = (t0 + 1648U);
    t10 = *((char **)t9);
    t17 = *((int64 *)t10);
    xsi_process_wait(t1, t17);

LAB9:    t9 = (t1 + 88U);
    t13 = *((char **)t9);
    t14 = (t13 + 2480U);
    *((unsigned int *)t14) = 1U;
    t15 = (t1 + 88U);
    t16 = *((char **)t15);
    t18 = (t16 + 0U);
    getcontext(t18);
    t19 = (t1 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 2480U);
    t22 = *((unsigned int *)t21);
    if (t22 == 1)
        goto LAB10;

LAB11:    t23 = (t1 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 2480U);
    *((unsigned int *)t25) = 3U;

LAB7:
LAB8:
LAB6:
LAB4:    if (t7 == t8)
        goto LAB5;

LAB12:    t6 = (t7 + -1);
    t7 = t6;
    goto LAB2;

LAB10:    xsi_saveStackAndSuspend(t1);
    goto LAB11;

}

static void work_a_1810025488_0224828019_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(34, ng1);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(35, ng1);
    t2 = (t0 + 2440);
    work_a_1810025488_0224828019_sub_2255900711_563975177(t0, t2, 1);
    xsi_set_current_line(36, ng1);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(37, ng1);
    t2 = (t0 + 2440);
    work_a_1810025488_0224828019_sub_2255900711_563975177(t0, t2, 40);
    xsi_set_current_line(38, ng1);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

}


extern void work_a_1810025488_0224828019_init()
{
	static char *pe[] = {(void *)work_a_1810025488_0224828019_p_0};
	static char *se[] = {(void *)work_a_1810025488_0224828019_sub_2255900711_563975177};
	xsi_register_didat("work_a_1810025488_0224828019", "isim/async_counter_tb_isim_beh.exe.sim/work/a_1810025488_0224828019.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
