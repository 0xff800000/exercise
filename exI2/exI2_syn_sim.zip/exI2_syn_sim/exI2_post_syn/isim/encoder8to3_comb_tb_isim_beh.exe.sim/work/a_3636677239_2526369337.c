/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/DYB/Documents/EPFL/Syn_sim/exI2_post_syn/encoder8to3_combinational.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_3636677239_2526369337_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    xsi_set_current_line(16, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t10 = xsi_get_transient_memory(3U);
    memset(t10, 0, 3U);
    t11 = t10;
    if (-1 == -1)
        goto LAB7;

LAB8:    t12 = 0;

LAB9:    t13 = (t12 - 2);
    t14 = (t13 * -1);
    t15 = (1U * t14);
    t16 = (t11 + t15);
    t17 = (1U * 3U);
    memset(t16, (unsigned char)2, t17);
    t18 = (t0 + 4552);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t10, 3U);
    xsi_driver_first_trans_fast_port(t18);

LAB2:    t23 = (t0 + 4392);
    *((int *)t23) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t1 = (t0 + 4552);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 3U);
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB6:    goto LAB2;

LAB7:    t12 = 2;
    goto LAB9;

}

static void work_a_3636677239_2526369337_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(17, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t10 = (6 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t18 = (5 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t22);
    t24 = (t0 + 1032U);
    t25 = *((char **)t24);
    t26 = (4 - 7);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t23, t30);
    t32 = (t0 + 4616);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t31;
    xsi_driver_first_trans_delta(t32, 0U, 1, 0LL);

LAB2:    t37 = (t0 + 4408);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3636677239_2526369337_p_2(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(18, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t10 = (6 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t18 = (3 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t22);
    t24 = (t0 + 1032U);
    t25 = *((char **)t24);
    t26 = (2 - 7);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t23, t30);
    t32 = (t0 + 4680);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t31;
    xsi_driver_first_trans_delta(t32, 1U, 1, 0LL);

LAB2:    t37 = (t0 + 4424);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3636677239_2526369337_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(19, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t10 = (5 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t18 = (3 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t22);
    t24 = (t0 + 1032U);
    t25 = *((char **)t24);
    t26 = (1 - 7);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t23, t30);
    t32 = (t0 + 4744);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t31;
    xsi_driver_first_trans_delta(t32, 2U, 1, 0LL);

LAB2:    t37 = (t0 + 4440);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3636677239_2526369337_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(21, ng0);

LAB3:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4808);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 4456);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3636677239_2526369337_p_5(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    unsigned char t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t25;
    unsigned int t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned char t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned char t39;
    unsigned int t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned char t46;
    unsigned int t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t60;
    unsigned int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;

LAB0:    xsi_set_current_line(22, ng0);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t8 = (t0 + 7308);
    t11 = 1;
    if (8U == 8U)
        goto LAB26;

LAB27:    t11 = 0;

LAB28:    if (t11 == 1)
        goto LAB23;

LAB24:    t15 = (t0 + 1032U);
    t16 = *((char **)t15);
    t15 = (t0 + 7316);
    t18 = 1;
    if (8U == 8U)
        goto LAB32;

LAB33:    t18 = 0;

LAB34:    t7 = t18;

LAB25:    if (t7 == 1)
        goto LAB20;

LAB21:    t22 = (t0 + 1032U);
    t23 = *((char **)t22);
    t22 = (t0 + 7324);
    t25 = 1;
    if (8U == 8U)
        goto LAB38;

LAB39:    t25 = 0;

LAB40:    t6 = t25;

LAB22:    if (t6 == 1)
        goto LAB17;

LAB18:    t29 = (t0 + 1032U);
    t30 = *((char **)t29);
    t29 = (t0 + 7332);
    t32 = 1;
    if (8U == 8U)
        goto LAB44;

LAB45:    t32 = 0;

LAB46:    t5 = t32;

LAB19:    if (t5 == 1)
        goto LAB14;

LAB15:    t36 = (t0 + 1032U);
    t37 = *((char **)t36);
    t36 = (t0 + 7340);
    t39 = 1;
    if (8U == 8U)
        goto LAB50;

LAB51:    t39 = 0;

LAB52:    t4 = t39;

LAB16:    if (t4 == 1)
        goto LAB11;

LAB12:    t43 = (t0 + 1032U);
    t44 = *((char **)t43);
    t43 = (t0 + 7348);
    t46 = 1;
    if (8U == 8U)
        goto LAB56;

LAB57:    t46 = 0;

LAB58:    t3 = t46;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t50 = (t0 + 1032U);
    t51 = *((char **)t50);
    t50 = (t0 + 7356);
    t53 = 1;
    if (8U == 8U)
        goto LAB62;

LAB63:    t53 = 0;

LAB64:    t2 = t53;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t57 = (t0 + 7364);
    t60 = 1;
    if (8U == 8U)
        goto LAB68;

LAB69:    t60 = 0;

LAB70:    t1 = t60;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB74:    t69 = (t0 + 4872);
    t70 = (t69 + 56U);
    t71 = *((char **)t70);
    t72 = (t71 + 56U);
    t73 = *((char **)t72);
    *((unsigned char *)t73) = (unsigned char)2;
    xsi_driver_first_trans_fast(t69);

LAB2:    t74 = (t0 + 4472);
    *((int *)t74) = 1;

LAB1:    return;
LAB3:    t64 = (t0 + 4872);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    *((unsigned char *)t68) = (unsigned char)3;
    xsi_driver_first_trans_fast(t64);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB11:    t3 = (unsigned char)1;
    goto LAB13;

LAB14:    t4 = (unsigned char)1;
    goto LAB16;

LAB17:    t5 = (unsigned char)1;
    goto LAB19;

LAB20:    t6 = (unsigned char)1;
    goto LAB22;

LAB23:    t7 = (unsigned char)1;
    goto LAB25;

LAB26:    t12 = 0;

LAB29:    if (t12 < 8U)
        goto LAB30;
    else
        goto LAB28;

LAB30:    t13 = (t9 + t12);
    t14 = (t8 + t12);
    if (*((unsigned char *)t13) != *((unsigned char *)t14))
        goto LAB27;

LAB31:    t12 = (t12 + 1);
    goto LAB29;

LAB32:    t19 = 0;

LAB35:    if (t19 < 8U)
        goto LAB36;
    else
        goto LAB34;

LAB36:    t20 = (t16 + t19);
    t21 = (t15 + t19);
    if (*((unsigned char *)t20) != *((unsigned char *)t21))
        goto LAB33;

LAB37:    t19 = (t19 + 1);
    goto LAB35;

LAB38:    t26 = 0;

LAB41:    if (t26 < 8U)
        goto LAB42;
    else
        goto LAB40;

LAB42:    t27 = (t23 + t26);
    t28 = (t22 + t26);
    if (*((unsigned char *)t27) != *((unsigned char *)t28))
        goto LAB39;

LAB43:    t26 = (t26 + 1);
    goto LAB41;

LAB44:    t33 = 0;

LAB47:    if (t33 < 8U)
        goto LAB48;
    else
        goto LAB46;

LAB48:    t34 = (t30 + t33);
    t35 = (t29 + t33);
    if (*((unsigned char *)t34) != *((unsigned char *)t35))
        goto LAB45;

LAB49:    t33 = (t33 + 1);
    goto LAB47;

LAB50:    t40 = 0;

LAB53:    if (t40 < 8U)
        goto LAB54;
    else
        goto LAB52;

LAB54:    t41 = (t37 + t40);
    t42 = (t36 + t40);
    if (*((unsigned char *)t41) != *((unsigned char *)t42))
        goto LAB51;

LAB55:    t40 = (t40 + 1);
    goto LAB53;

LAB56:    t47 = 0;

LAB59:    if (t47 < 8U)
        goto LAB60;
    else
        goto LAB58;

LAB60:    t48 = (t44 + t47);
    t49 = (t43 + t47);
    if (*((unsigned char *)t48) != *((unsigned char *)t49))
        goto LAB57;

LAB61:    t47 = (t47 + 1);
    goto LAB59;

LAB62:    t54 = 0;

LAB65:    if (t54 < 8U)
        goto LAB66;
    else
        goto LAB64;

LAB66:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB63;

LAB67:    t54 = (t54 + 1);
    goto LAB65;

LAB68:    t61 = 0;

LAB71:    if (t61 < 8U)
        goto LAB72;
    else
        goto LAB70;

LAB72:    t62 = (t58 + t61);
    t63 = (t57 + t61);
    if (*((unsigned char *)t62) != *((unsigned char *)t63))
        goto LAB69;

LAB73:    t61 = (t61 + 1);
    goto LAB71;

LAB75:    goto LAB2;

}


extern void work_a_3636677239_2526369337_init()
{
	static char *pe[] = {(void *)work_a_3636677239_2526369337_p_0,(void *)work_a_3636677239_2526369337_p_1,(void *)work_a_3636677239_2526369337_p_2,(void *)work_a_3636677239_2526369337_p_3,(void *)work_a_3636677239_2526369337_p_4,(void *)work_a_3636677239_2526369337_p_5};
	xsi_register_didat("work_a_3636677239_2526369337", "isim/encoder8to3_comb_tb_isim_beh.exe.sim/work/a_3636677239_2526369337.didat");
	xsi_register_executes(pe);
}
