/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_2592010699;
static const char *ng1 = "C:/Users/DYB/Documents/EPFL/Syn_sim/exII3_post_syn/fb_reg_tb.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );


void work_a_4199497387_0224828019_sub_2255900711_563975177(char *t0, char *t1, int t2)
{
    char t4[8];
    char *t5;
    int t6;
    int t7;
    int t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int64 t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t5 = (t4 + 4U);
    *((int *)t5) = t2;
    t6 = (t2 - 1);
    t7 = t6;
    t8 = 0;

LAB2:    if (t7 >= t8)
        goto LAB3;

LAB5:
LAB1:    return;
LAB3:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t11);
    t9 = (t0 + 3240);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t12;
    xsi_driver_first_trans_fast(t9);
    t9 = (t0 + 1808U);
    t10 = *((char **)t9);
    t17 = *((int64 *)t10);
    xsi_process_wait(t1, t17);

LAB9:    t9 = (t1 + 88U);
    t13 = *((char **)t9);
    t14 = (t13 + 2480U);
    *((unsigned int *)t14) = 1U;
    t15 = (t1 + 88U);
    t16 = *((char **)t15);
    t18 = (t16 + 0U);
    getcontext(t18);
    t19 = (t1 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 2480U);
    t22 = *((unsigned int *)t21);
    if (t22 == 1)
        goto LAB10;

LAB11:    t23 = (t1 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 2480U);
    *((unsigned int *)t25) = 3U;

LAB7:
LAB8:
LAB6:
LAB4:    if (t7 == t8)
        goto LAB5;

LAB12:    t6 = (t7 + -1);
    t7 = t6;
    goto LAB2;

LAB10:    xsi_saveStackAndSuspend(t1);
    goto LAB11;

}

static void work_a_4199497387_0224828019_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    int t9;
    int t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(34, ng1);
    t2 = (t0 + 3176);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(35, ng1);
    t2 = (t0 + 2600);
    work_a_4199497387_0224828019_sub_2255900711_563975177(t0, t2, 1);
    xsi_set_current_line(36, ng1);
    t2 = (t0 + 3176);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(38, ng1);
    if (255 > 0)
        goto LAB8;

LAB9:    if (-1 == -1)
        goto LAB13;

LAB14:    t7 = 0;

LAB10:    t8 = (t7 * 2);
    t9 = (t8 / 2);
    t2 = (t0 + 5714);
    *((int *)t2) = t9;
    t3 = (t0 + 5718);
    *((int *)t3) = 0;
    t10 = t9;
    t11 = 0;

LAB4:    if (t10 >= t11)
        goto LAB5;

LAB7:    xsi_set_current_line(44, ng1);

LAB20:    *((char **)t1) = &&LAB21;

LAB1:    return;
LAB5:    xsi_set_current_line(39, ng1);
    t4 = (t0 + 2600);
    work_a_4199497387_0224828019_sub_2255900711_563975177(t0, t4, 2);
    xsi_set_current_line(40, ng1);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t2 = (t0 + 1352U);
    t4 = *((char **)t2);
    t2 = (t0 + 5400U);
    t7 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t4, t2);
    t8 = (t7 - 255);
    t12 = (t8 * -1);
    xsi_vhdl_check_range_of_index(255, 0, -1, t7);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t5 = (t3 + t14);
    t15 = *((unsigned char *)t5);
    t16 = ((unsigned char)2 == t15);
    if (t16 == 0)
        goto LAB15;

LAB16:    xsi_set_current_line(42, ng1);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 5400U);
    t7 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t3, t2);
    t8 = (t7 - 255);
    t12 = (t8 * -1);
    t13 = (1 * t12);
    t14 = (0U + t13);
    t4 = (t0 + 3304);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t17 = (t6 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_delta(t4, t14, 1, 0LL);

LAB6:    t2 = (t0 + 5714);
    t10 = *((int *)t2);
    t3 = (t0 + 5718);
    t11 = *((int *)t3);
    if (t10 == t11)
        goto LAB7;

LAB17:    t7 = (t10 + -1);
    t10 = t7;
    t4 = (t0 + 5714);
    *((int *)t4) = t10;
    goto LAB4;

LAB8:    if (-1 == 1)
        goto LAB11;

LAB12:    t7 = 255;
    goto LAB10;

LAB11:    t7 = 0;
    goto LAB10;

LAB13:    t7 = 255;
    goto LAB10;

LAB15:    t6 = (t0 + 5722);
    xsi_report(t6, 6U, 2);
    goto LAB16;

LAB18:    goto LAB2;

LAB19:    goto LAB18;

LAB21:    goto LAB19;

}


extern void work_a_4199497387_0224828019_init()
{
	static char *pe[] = {(void *)work_a_4199497387_0224828019_p_0};
	static char *se[] = {(void *)work_a_4199497387_0224828019_sub_2255900711_563975177};
	xsi_register_didat("work_a_4199497387_0224828019", "isim/fb_reg_tb_isim_beh.exe.sim/work/a_4199497387_0224828019.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
