/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_1242562249;
static const char *ng1 = "C:/Users/DYB/Documents/EPFL/Syn_sim/exI3_post_syn/barrelshift8_tb_direct.vhd";

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_2505484506_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2547962040_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_3064532541_1035706684(char *, char *, char *, char *, int );


void work_a_3942822837_0224828019_sub_1890480940_2447733330(char *t0, char *t1, int t2)
{
    char t4[8];
    char t16[16];
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    int64 t25;
    int64 t26;

LAB0:    t5 = (t4 + 4U);
    *((int *)t5) = t2;
    t6 = (t0 + 6574);
    t8 = (t0 + 3680);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t0 + 6492U);
    t14 = (t13 + 12U);
    t15 = *((unsigned int *)t14);
    t15 = (t15 * 1U);
    memcpy(t12, t6, t15);
    xsi_driver_first_trans_fast(t8);
    t6 = (t0 + 3744);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t6);
    t6 = (t0 + 6508U);
    t7 = (t6 + 12U);
    t15 = *((unsigned int *)t7);
    t8 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t16, t2, ((t15)));
    t9 = (t0 + 3808);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t0 + 6508U);
    t17 = (t14 + 12U);
    t18 = *((unsigned int *)t17);
    t18 = (t18 * 1U);
    memcpy(t13, t8, t18);
    xsi_driver_first_trans_fast(t9);
    t6 = (t0 + 1032U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = ieee_p_1242562249_sub_2547962040_1035706684(IEEE_P_1242562249, t16, t7, t6, t2);
    t9 = (t0 + 6476U);
    t10 = (t9 + 12U);
    t15 = *((unsigned int *)t10);
    t15 = (t15 * 1U);
    t11 = (t16 + 12U);
    t18 = *((unsigned int *)t11);
    t19 = (1U * t18);
    t20 = (t15 != t19);
    if (t20 == 1)
        goto LAB2;

LAB3:    t12 = (t0 + 3872);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t17 = (t14 + 56U);
    t21 = *((char **)t17);
    t22 = (t0 + 6476U);
    t23 = (t22 + 12U);
    t24 = *((unsigned int *)t23);
    t24 = (t24 * 1U);
    memcpy(t21, t8, t24);
    xsi_driver_first_trans_fast(t12);
    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t25 = *((int64 *)t7);
    xsi_process_wait(t1, t25);

LAB7:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB8;

LAB9:    t21 = (t1 + 88U);
    t22 = *((char **)t21);
    t23 = (t22 + 2480U);
    *((unsigned int *)t23) = 3U;

LAB5:
LAB6:
LAB4:    t6 = (t0 + 6576);
    xsi_report(t6, 9U, 0);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = (t6 + 12U);
    t15 = *((unsigned int *)t8);
    t15 = (t15 * 1U);
    t9 = (t0 + 1352U);
    t10 = *((char **)t9);
    t9 = (t0 + 6476U);
    t11 = (t9 + 12U);
    t18 = *((unsigned int *)t11);
    t18 = (t18 * 1U);
    t20 = 1;
    if (t15 == t18)
        goto LAB12;

LAB13:    t20 = 0;

LAB14:    if (t20 == 0)
        goto LAB10;

LAB11:    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t25 = *((int64 *)t7);
    t26 = (t25 / 2);
    xsi_process_wait(t1, t26);

LAB21:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB22;

LAB23:    t21 = (t1 + 88U);
    t22 = *((char **)t21);
    t23 = (t22 + 2480U);
    *((unsigned int *)t23) = 3U;

LAB19:
LAB20:
LAB18:
LAB1:    return;
LAB2:    xsi_size_not_matching(t15, t19, 0);
    goto LAB3;

LAB8:    xsi_saveStackAndSuspend(t1);
    goto LAB9;

LAB10:    t14 = (t0 + 6585);
    xsi_report(t14, 10U, 2);
    goto LAB11;

LAB12:    t19 = 0;

LAB15:    if (t19 < t15)
        goto LAB16;
    else
        goto LAB14;

LAB16:    t12 = (t7 + t19);
    t13 = (t10 + t19);
    if (*((unsigned char *)t12) != *((unsigned char *)t13))
        goto LAB13;

LAB17:    t19 = (t19 + 1);
    goto LAB15;

LAB22:    xsi_saveStackAndSuspend(t1);
    goto LAB23;

}

void work_a_3942822837_0224828019_sub_1877435809_2447733330(char *t0, char *t1, int t2)
{
    char t4[8];
    char t16[16];
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    char *t17;
    unsigned int t18;
    int64 t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned char t23;
    unsigned int t24;
    int64 t25;

LAB0:    t5 = (t4 + 4U);
    *((int *)t5) = t2;
    t6 = (t0 + 6595);
    t8 = (t0 + 3680);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t0 + 6492U);
    t14 = (t13 + 12U);
    t15 = *((unsigned int *)t14);
    t15 = (t15 * 1U);
    memcpy(t12, t6, t15);
    xsi_driver_first_trans_fast(t8);
    t6 = (t0 + 3744);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)1;
    xsi_driver_first_trans_fast(t6);
    t6 = (t0 + 6508U);
    t7 = (t6 + 12U);
    t15 = *((unsigned int *)t7);
    t8 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t16, t2, ((t15)));
    t9 = (t0 + 3808);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t0 + 6508U);
    t17 = (t14 + 12U);
    t18 = *((unsigned int *)t17);
    t18 = (t18 * 1U);
    memcpy(t13, t8, t18);
    xsi_driver_first_trans_fast(t9);
    t6 = (t0 + 1032U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = ieee_p_1242562249_sub_3064532541_1035706684(IEEE_P_1242562249, t16, t7, t6, t2);
    t9 = (t0 + 3872);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t0 + 6476U);
    t17 = (t14 + 12U);
    t15 = *((unsigned int *)t17);
    t15 = (t15 * 1U);
    memcpy(t13, t8, t15);
    xsi_driver_first_trans_fast(t9);
    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t19 = *((int64 *)t7);
    xsi_process_wait(t1, t19);

LAB5:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB6;

LAB7:    t20 = (t1 + 88U);
    t21 = *((char **)t20);
    t22 = (t21 + 2480U);
    *((unsigned int *)t22) = 3U;

LAB3:
LAB4:
LAB2:    t6 = (t0 + 6597);
    xsi_report(t6, 9U, 0);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = (t6 + 12U);
    t15 = *((unsigned int *)t8);
    t15 = (t15 * 1U);
    t9 = (t0 + 1352U);
    t10 = *((char **)t9);
    t9 = (t0 + 6476U);
    t11 = (t9 + 12U);
    t18 = *((unsigned int *)t11);
    t18 = (t18 * 1U);
    t23 = 1;
    if (t15 == t18)
        goto LAB10;

LAB11:    t23 = 0;

LAB12:    if (t23 == 0)
        goto LAB8;

LAB9:    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t19 = *((int64 *)t7);
    t25 = (t19 / 2);
    xsi_process_wait(t1, t25);

LAB19:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB20;

LAB21:    t20 = (t1 + 88U);
    t21 = *((char **)t20);
    t22 = (t21 + 2480U);
    *((unsigned int *)t22) = 3U;

LAB17:
LAB18:
LAB16:
LAB1:    return;
LAB6:    xsi_saveStackAndSuspend(t1);
    goto LAB7;

LAB8:    t14 = (t0 + 6606);
    xsi_report(t14, 10U, 2);
    goto LAB9;

LAB10:    t24 = 0;

LAB13:    if (t24 < t15)
        goto LAB14;
    else
        goto LAB12;

LAB14:    t12 = (t7 + t24);
    t13 = (t10 + t24);
    if (*((unsigned char *)t12) != *((unsigned char *)t13))
        goto LAB11;

LAB15:    t24 = (t24 + 1);
    goto LAB13;

LAB20:    xsi_saveStackAndSuspend(t1);
    goto LAB21;

}

void work_a_3942822837_0224828019_sub_2225717631_2447733330(char *t0, char *t1, int t2)
{
    char t4[8];
    char t16[16];
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    int64 t25;
    int64 t26;

LAB0:    t5 = (t4 + 4U);
    *((int *)t5) = t2;
    t6 = (t0 + 6616);
    t8 = (t0 + 3680);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t0 + 6492U);
    t14 = (t13 + 12U);
    t15 = *((unsigned int *)t14);
    t15 = (t15 * 1U);
    memcpy(t12, t6, t15);
    xsi_driver_first_trans_fast(t8);
    t6 = (t0 + 3744);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t6);
    t6 = (t0 + 6508U);
    t7 = (t6 + 12U);
    t15 = *((unsigned int *)t7);
    t8 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t16, t2, ((t15)));
    t9 = (t0 + 3808);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t0 + 6508U);
    t17 = (t14 + 12U);
    t18 = *((unsigned int *)t17);
    t18 = (t18 * 1U);
    memcpy(t13, t8, t18);
    xsi_driver_first_trans_fast(t9);
    t6 = (t0 + 1032U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = ieee_p_1242562249_sub_2505484506_1035706684(IEEE_P_1242562249, t16, t7, t6, t2);
    t9 = (t0 + 6476U);
    t10 = (t9 + 12U);
    t15 = *((unsigned int *)t10);
    t15 = (t15 * 1U);
    t11 = (t16 + 12U);
    t18 = *((unsigned int *)t11);
    t19 = (1U * t18);
    t20 = (t15 != t19);
    if (t20 == 1)
        goto LAB2;

LAB3:    t12 = (t0 + 3872);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t17 = (t14 + 56U);
    t21 = *((char **)t17);
    t22 = (t0 + 6476U);
    t23 = (t22 + 12U);
    t24 = *((unsigned int *)t23);
    t24 = (t24 * 1U);
    memcpy(t21, t8, t24);
    xsi_driver_first_trans_fast(t12);
    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t25 = *((int64 *)t7);
    xsi_process_wait(t1, t25);

LAB7:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB8;

LAB9:    t21 = (t1 + 88U);
    t22 = *((char **)t21);
    t23 = (t22 + 2480U);
    *((unsigned int *)t23) = 3U;

LAB5:
LAB6:
LAB4:    t6 = (t0 + 6618);
    xsi_report(t6, 8U, 0);
    t6 = (t0 + 1192U);
    t7 = *((char **)t6);
    t6 = (t0 + 6460U);
    t8 = (t6 + 12U);
    t15 = *((unsigned int *)t8);
    t15 = (t15 * 1U);
    t9 = (t0 + 1352U);
    t10 = *((char **)t9);
    t9 = (t0 + 6476U);
    t11 = (t9 + 12U);
    t18 = *((unsigned int *)t11);
    t18 = (t18 * 1U);
    t20 = 1;
    if (t15 == t18)
        goto LAB12;

LAB13:    t20 = 0;

LAB14:    if (t20 == 0)
        goto LAB10;

LAB11:    t6 = (t0 + 2128U);
    t7 = *((char **)t6);
    t25 = *((int64 *)t7);
    t26 = (t25 / 2);
    xsi_process_wait(t1, t26);

LAB21:    t6 = (t1 + 88U);
    t8 = *((char **)t6);
    t9 = (t8 + 2480U);
    *((unsigned int *)t9) = 1U;
    t10 = (t1 + 88U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    getcontext(t12);
    t13 = (t1 + 88U);
    t14 = *((char **)t13);
    t17 = (t14 + 2480U);
    t15 = *((unsigned int *)t17);
    if (t15 == 1)
        goto LAB22;

LAB23:    t21 = (t1 + 88U);
    t22 = *((char **)t21);
    t23 = (t22 + 2480U);
    *((unsigned int *)t23) = 3U;

LAB19:
LAB20:
LAB18:
LAB1:    return;
LAB2:    xsi_size_not_matching(t15, t19, 0);
    goto LAB3;

LAB8:    xsi_saveStackAndSuspend(t1);
    goto LAB9;

LAB10:    t14 = (t0 + 6626);
    xsi_report(t14, 9U, 2);
    goto LAB11;

LAB12:    t19 = 0;

LAB15:    if (t19 < t15)
        goto LAB16;
    else
        goto LAB14;

LAB16:    t12 = (t7 + t19);
    t13 = (t10 + t19);
    if (*((unsigned char *)t12) != *((unsigned char *)t13))
        goto LAB13;

LAB17:    t19 = (t19 + 1);
    goto LAB15;

LAB22:    xsi_saveStackAndSuspend(t1);
    goto LAB23;

}

static void work_a_3942822837_0224828019_p_0(char *t0)
{
    char t3[16];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int64 t9;
    int t10;
    int t11;
    int t12;

LAB0:    t1 = (t0 + 3232U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng1);
    t2 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t3, 206, 8);
    t4 = (t0 + 3616);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 8U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(66, ng1);
    t2 = (t0 + 2128U);
    t4 = *((char **)t2);
    t9 = *((int64 *)t4);
    t2 = (t0 + 3040);
    xsi_process_wait(t2, t9);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(67, ng1);
    t10 = (8U - 1);
    t2 = (t0 + 6635);
    *((int *)t2) = 0;
    t4 = (t0 + 6639);
    *((int *)t4) = t10;
    t11 = 0;
    t12 = t10;

LAB8:    if (t11 <= t12)
        goto LAB9;

LAB11:    xsi_set_current_line(72, ng1);

LAB15:    *((char **)t1) = &&LAB16;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(68, ng1);
    t5 = (t0 + 3040);
    t6 = (t0 + 6635);
    work_a_3942822837_0224828019_sub_1890480940_2447733330(t0, t5, *((int *)t6));
    xsi_set_current_line(69, ng1);
    t2 = (t0 + 3040);
    t4 = (t0 + 6635);
    work_a_3942822837_0224828019_sub_1877435809_2447733330(t0, t2, *((int *)t4));
    xsi_set_current_line(70, ng1);
    t2 = (t0 + 3040);
    t4 = (t0 + 6635);
    work_a_3942822837_0224828019_sub_2225717631_2447733330(t0, t2, *((int *)t4));

LAB10:    t2 = (t0 + 6635);
    t11 = *((int *)t2);
    t4 = (t0 + 6639);
    t12 = *((int *)t4);
    if (t11 == t12)
        goto LAB11;

LAB12:    t10 = (t11 + 1);
    t11 = t10;
    t5 = (t0 + 6635);
    *((int *)t5) = t11;
    goto LAB8;

LAB13:    goto LAB2;

LAB14:    goto LAB13;

LAB16:    goto LAB14;

}


extern void work_a_3942822837_0224828019_init()
{
	static char *pe[] = {(void *)work_a_3942822837_0224828019_p_0};
	static char *se[] = {(void *)work_a_3942822837_0224828019_sub_1890480940_2447733330,(void *)work_a_3942822837_0224828019_sub_1877435809_2447733330,(void *)work_a_3942822837_0224828019_sub_2225717631_2447733330};
	xsi_register_didat("work_a_3942822837_0224828019", "isim/barrelshift8_tb_isim_beh.exe.sim/work/a_3942822837_0224828019.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
